1. Admin will manage the funding opportunities and grants.
2. Investors can see their investments. 

Everthing is as per phase2, instead it was a static website before, now it is dynamic with a database. 
# Application Login Information

Below are the test user accounts that can be used to access the application.

## Test Accounts

### Admin User
- **Email:** admin@app.com
- **Password:** password

### Event Organizer
- **Email:** organizer@app.com
- **Password:** password

### Investor
- **Email:** investor@app.com
- **Password:** password

### Regular Users
1. **First User**
   - **Email:** user@app.com
   - **Password:** password

2. **Sarah Johnson**
   - **Email:** sarah@app.com
   - **Password:** password

3. **Michael Chen**
   - **Email:** michael@app.com
   - **Password:** password
